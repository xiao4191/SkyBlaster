using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public int pointValue = 1000;
    public bool activateShield;
    public bool addGuns;
    public bool increaseSpeed;
}
