using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Level : MonoBehaviour
{
    public static Level instance;
    public uint numDestructables = 0;
    public bool startNextLevel = false;
    public bool gameOver = false;
    public float nextLevelTimer = 3;

    public string[] levels = { "Level1", "Level2", "Level3" };
    public int currentLevel = 1;
    public int score = 0;
    public int playerLife = 3;
    public Text scoreText;
    public Text lifeText;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
            scoreText = GameObject.Find("ScoreText").GetComponent<Text>();
            lifeText = GameObject.Find("LifeText").GetComponent<Text>();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        UpdateLifeUI();
    }

    void Update()
    {
        // Check if the game is over
        if (!gameOver && startNextLevel)
        {
            if (nextLevelTimer <= 0)
            {
                currentLevel++;
                if (currentLevel <= levels.Length)
                {
                    string sceneName = levels[currentLevel - 1];
                    SceneManager.LoadSceneAsync(sceneName);
                }
                else
                {
                    Debug.Log("GAME OVER!!!");
                    // Set game over when all levels are completed
                    gameOver = true;
                    PauseGame();
                }
                nextLevelTimer = 3;
                startNextLevel = false;
            }
            else
            {
                nextLevelTimer -= Time.deltaTime;
            }
        }
    }

    public void RestartGame()
    {
        gameOver = false;
        currentLevel = 1;
        Time.timeScale = 1;
        ResetLevel();
    }

    public void ResetLevel()
    {
        foreach (Bullet b in GameObject.FindObjectsOfType<Bullet>())
        {
            Destroy(b.gameObject);
        }
        numDestructables = 0;
        score = 0;
        playerLife = 4;
        AddScore(score);
        UpdateLifeUI();
        string sceneName = levels[currentLevel - 1];
        SceneManager.LoadScene(sceneName);
    }

    public void AddScore(int amountToAdd)
    {
        score += amountToAdd;
        scoreText.text = score.ToString();
    }

    public void AddDestructable()
    {
        numDestructables++;
    }

    public void RemoveDestructable()
    {
        numDestructables--;

        if (numDestructables == 0)
        {
            startNextLevel = true;
        }
    }

    // Method to update the UI to display player life count
    void UpdateLifeUI()
    {
        lifeText.text = playerLife.ToString();
    }

    public void PlayerHit()
    {
        ReduceLife();
    }

    // Method to reduce player life count
    public void ReduceLife()
    {
        playerLife--;
        UpdateLifeUI();

        if (playerLife <= 0)
        {
            Debug.Log("GAME OVER!!!");
            gameOver = true;
            RestartGame();
        }
    }

    void PauseGame()
    {
        Time.timeScale = 0;
    }
}
